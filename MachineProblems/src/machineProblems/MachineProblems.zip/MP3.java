package machineProblems;
import javax.swing.JFrame;


public class MP3 {

	public static void main(String[] args) {
		JFrame m = new MP3GUI();
		m.setVisible(true);
	}
}
