package machineProblems;

public class Controller {
	
	public static void main(String[] args) {
		GUI cipher = new GUI();
		cipher.setVisible(true);
	}
}
